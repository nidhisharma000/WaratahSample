(function() {
var toc =  [{"type":"item","name":"001_SampleTask","url":"001_SampleTask.htm"}];
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), toc, { sync:true });
})();